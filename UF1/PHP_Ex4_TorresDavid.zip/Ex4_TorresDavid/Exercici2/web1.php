<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Web1 - Ex2</title>
</head>
<body>
    <?php
        /* Fes un programa per fer una calculadora amb botons */
        $login = $logout = "";
        if ($_SERVER["REQUEST_METHOD"] == "POST") { // En cas que el request method sigui "GET", cridarà la funció test_input per cada variable
            $login = test_input($_POST["login"]);
            $logout = test_input($_POST["logout"]);
            }

            function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
            }
    ?>
 
        <h1> FORMULARI </h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
        EMAIL: <input type="text" name="email">
        PASSWORD: <input type="text" name="pass">
        <input type="submit" name="login" value="LOGIN">
        <input type="submit" name="logout" value="LOGOUT">

    <?php   
        session_start();
        session_cache_expire(1);
        if (!empty($_POST["email"]) && !empty($_POST["pass"])){
            echo "Benvingut";
            if ($logout){
                header("Location:header.php");
            }
        } else {
            echo "FALTA INFORMACIÓ";
        }

        

    ?>

</body>
</html>