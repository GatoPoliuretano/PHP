<!-- Fes una plantilla amb un header, footer, i hi haurà un enllaç a cada exercici. Utilitza el més adient:  include, require ...  -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - David Torres</title>
</head>

<footer>
    <p> Copyright © - David Torres</p>
</footer>
</html>